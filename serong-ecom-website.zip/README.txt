SERONG ECOM - how to put this website online

1. Go to https://app.netlify.com/drop (free, no coding).
2. Drag the folder containing index.html onto the page.
3. Netlify gives you a live link. Open it and submit a test inquiry.
4. Your form sends to Formspree (https://formspree.io/f/meaezwzy).
   Make sure your Formspree account email is mentoshipserong@gmail.com
   and confirm the form if Formspree asks.

Other free hosts: Vercel, Cloudflare Pages, GitHub Pages.
To use your own domain, add it in the host's Domains settings.
